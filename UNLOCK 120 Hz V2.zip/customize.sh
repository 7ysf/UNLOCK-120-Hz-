#Print welcome message
ui_print "- flashing PUBG High Graphcs Unlock module..."
ui_print "- By telegram username @ysf_in"
ui_print " ENJOY HUGH GRAPHICS AND SUPER SMOOTH"